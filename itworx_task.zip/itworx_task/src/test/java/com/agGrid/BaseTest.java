package com.agGrid;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.*;
//import utilis.Logs.Log;

import static factories.browserFactory.*;

public class BaseTest {

    public WebDriver driver;

    @BeforeSuite
    @Parameters ({"browser", "url"})
     public void setup( @Optional("chrome")  String browser, @Optional("https://www.ag-grid.com/example.php") String url) {
        driver = setDriver(driver, browser);
        Reporter.log("Driver is: " + browser);
        driver.get(url);

      }

    @AfterSuite
    public void tearDown() {
        closeDriver();
        Reporter.log("Driver is closed successfully");
    }

    public WebDriver getDriver(){
        return driver;
    }

}

