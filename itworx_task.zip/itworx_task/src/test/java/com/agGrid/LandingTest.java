package com.agGrid;

import com.agGrid.pages.LandingPage;
import org.testng.Assert;
import org.testng.annotations.*;
//import utilis.Logs.Log;


public class LandingTest extends BaseTest {

    @Test
    public void landingPageTests() throws InterruptedException {

        LandingPage landingPage = new LandingPage(getDriver());
        landingPage.filterLang("French");
        landingPage.filterCountry("Belgium");
        landingPage.closeFitler();
        String value = landingPage.getJanValue();
        Assert.assertEquals(value,"$66,433","Values are equals");
    }

 }