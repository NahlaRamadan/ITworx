package com.agGrid.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class LandingPage extends BasePage {

    public LandingPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//input[@id='ag-121-input']")
    WebElement langFilterTxtBx;

    @FindBy(xpath = "//div[@class='ag-header-cell ag-floating-filter ag-focus-managed' and @aria-colindex='3']/descendant::div[@class='ag-floating-filter-button']")
    WebElement countryFilterBtn;

    @FindBy(xpath = "//div[@class='ag-wrapper ag-input-wrapper ag-text-field-input-wrapper']/descendant::input[@aria-label='Search filter values']")
    WebElement countryFilterInput;

    @FindBy(xpath = "//div[@ref='centerContainer']//descendant::div[@col-id='jan']")
    WebElement janCell;

    @FindBy(xpath = "//div[@class='options-expander']")
    WebElement win;

    @FindBy(xpath = "//div[@class='ag-center-cols-viewport']")
    WebElement grid;
    public void filterLang(String language) {
        langFilterTxtBx.sendKeys(language);
    }

    public void filterCountry(String country) throws InterruptedException {
        countryFilterBtn.click();
        countryFilterInput.sendKeys(country);
        countryFilterInput.sendKeys(Keys.ENTER);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft = arguments[0].offsetWidth", grid);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    public String getJanValue(){
        return janCell.getText();

    }

    public void closeFitler(){
        win.click();
    }

}
