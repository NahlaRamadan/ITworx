package factories;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class browserFactory {

    private static Map<String, WebDriver> drivers = new HashMap<String, WebDriver>();
    private static WebDriverWait wait;

    public static WebDriver setDriver(WebDriver driver,  String browserName) {

        switch (browserName.toLowerCase()) {
            case "chrome":
                driver = drivers.get("chrome");
                if (driver == null) {
                    WebDriverManager.chromedriver().setup();
                    driver = new ChromeDriver();
                    drivers.put("chrome", driver);
                }
                break;

            case "firefox":
                driver = drivers.get("firefox");
                if (driver == null) {
                    WebDriverManager.firefoxdriver().setup();
                    driver = new FirefoxDriver();
                    drivers.put("firefox", driver);
                }
                break;

            case "ie":
                driver = drivers.get("ie");
                if (driver == null) {
                    WebDriverManager.iedriver().setup();
                    driver = new InternetExplorerDriver();
                    drivers.put("ie", driver);
                }
                break;
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return driver;
    }
        public static void closeDriver() {
            for (String key : drivers.keySet()) {
                drivers.get(key).close();
               // drivers.get(key).quit();
            }
        }
}